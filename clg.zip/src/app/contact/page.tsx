"use client";
import React from "react";
import { motion } from "framer-motion";
import Navbar from "@/components/landing/Navbar";
import { MapPin, Phone, Mail, Clock, Send, Globe, MessageSquare } from "lucide-react";

export default function ContactPage() {
  return (
    <main className="min-h-screen bg-white selection:bg-orange-600 selection:text-white overflow-x-hidden">
      {/* Navbar active for sub-page visibility */}
      <Navbar isScrolled={true} />

      {/* --- HERO SECTION --- */}
      <section className="relative pt-44 pb-24 bg-slate-950 text-white overflow-hidden">
        <div className="absolute inset-0 z-0 opacity-20">
          <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-orange-600 rounded-full blur-[150px] -translate-y-1/2 translate-x-1/2" />
        </div>
        
        <div className="max-w-7xl mx-auto px-6 relative z-10">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }}>
            <span className="text-orange-500 font-black uppercase tracking-[0.4em] text-[10px]">Get In Touch</span>
            <h1 className="text-6xl md:text-9xl font-black uppercase italic tracking-tighter mt-4 leading-none">
              Connect with <br /> <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-500 to-yellow-400">VIT.</span>
            </h1>
            <p className="mt-8 text-slate-400 font-light text-lg max-w-2xl leading-relaxed">
              Have questions about admissions, placements, or campus life? Our dedicated support team is here to guide you through every step of your professional journey at Vanguard Institute of Technology.
            </p>
          </motion.div>
        </div>
      </section>

      {/* --- CONTACT GRID --- */}
      <section className="py-24 max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-20">
          
          {/* LEFT: INQUIRY FORM */}
          <motion.div 
            initial={{ opacity: 0, x: -30 }} 
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="bg-slate-50 p-10 md:p-16 border border-slate-100"
          >
            <h2 className="text-4xl font-black uppercase tracking-tighter text-slate-900 mb-8">Direct <span className="text-orange-600">Inquiry.</span></h2>
            <form className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Full Name</label>
                  <input type="text" className="w-full p-4 bg-white border border-slate-200 outline-none focus:border-orange-600 transition-all text-sm" placeholder="John Doe" />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Email Address</label>
                  <input type="email" className="w-full p-4 bg-white border border-slate-200 outline-none focus:border-orange-600 transition-all text-sm" placeholder="john@example.com" />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Subject</label>
                <select className="w-full p-4 bg-white border border-slate-200 outline-none focus:border-orange-600 transition-all text-sm appearance-none">
                  <option>Admission Query 2026</option>
                  <option>Placement Assistance</option>
                  <option>Corporate Partnership</option>
                  <option>General Information</option>
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Message</label>
                <textarea rows={5} className="w-full p-4 bg-white border border-slate-200 outline-none focus:border-orange-600 transition-all text-sm resize-none" placeholder="How can we help you today?"></textarea>
              </div>
              <button className="w-full bg-slate-950 text-white font-black py-5 uppercase tracking-[0.2em] text-xs hover:bg-orange-600 transition-all flex items-center justify-center gap-3">
                Submit Message <Send className="w-4 h-4" />
              </button>
            </form>
          </motion.div>

          {/* RIGHT: CONTACT INFO */}
          <motion.div 
            initial={{ opacity: 0, x: 30 }} 
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="flex flex-col justify-center space-y-12"
          >
            <div>
              <h3 className="text-2xl font-black uppercase tracking-tight text-slate-900 mb-6 flex items-center gap-4">
                <MapPin className="text-orange-600" /> Main Campus
              </h3>
              <p className="text-slate-500 leading-relaxed font-medium">
                VIT Campus, Sector 15, <br />
                Navi Mumbai, Maharashtra 400614 <br />
                India
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-12">
              <div>
                <h4 className="text-[10px] font-black uppercase text-slate-400 tracking-[0.3em] mb-4">Call Us</h4>
                <p className="text-lg font-black text-slate-900">+91 22 1234 5678</p>
                <p className="text-slate-500 text-xs mt-1">Mon - Sat, 9AM to 6PM</p>
              </div>
              <div>
                <h4 className="text-[10px] font-black uppercase text-slate-400 tracking-[0.3em] mb-4">Email Us</h4>
                <p className="text-lg font-black text-slate-900">info@vit.ac.in</p>
                <p className="text-slate-500 text-xs mt-1">Response within 24 hours</p>
              </div>
            </div>

            <div className="pt-8 border-t border-slate-100">
              <h4 className="text-[10px] font-black uppercase text-slate-400 tracking-[0.3em] mb-6">Quick Links</h4>
              <div className="flex flex-wrap gap-4">
                {[
                  { label: "WhatsApp Support", icon: <MessageSquare className="w-4 h-4" /> },
                  { label: "Admissions Portal", icon: <Globe className="w-4 h-4" /> },
                  { label: "Campus Map", icon: <MapPin className="w-4 h-4" /> }
                ].map((link, i) => (
                  <button key={i} className="flex items-center gap-2 px-6 py-3 bg-slate-50 border border-slate-100 text-[10px] font-bold uppercase tracking-widest hover:bg-orange-600 hover:text-white transition-all">
                    {link.icon} {link.label}
                  </button>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* --- GOOGLE MAPS PLACEHOLDER --- */}
      <section className="h-[400px] w-full bg-slate-200 grayscale hover:grayscale-0 transition-all duration-1000">
        <iframe 
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3771.4815416047716!2d73.023246!3d19.043632!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMTnCsDAyJzM3LjEiTiA3M8KwMDEnMjMuNyJF!5e0!3m2!1sen!2sin!4v1640000000000!5m2!1sen!2sin" 
          width="100%" 
          height="100%" 
          style={{ border: 0 }} 
          allowFullScreen 
          loading="lazy"
        ></iframe>
      </section>

      <footer className="py-12 bg-white text-center border-t border-slate-100">
        <p className="text-[10px] font-black text-slate-300 uppercase tracking-[1em]">VIT • Communications Dept • 2026</p>
      </footer>
    </main>
  );
}