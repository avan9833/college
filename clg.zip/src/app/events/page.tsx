"use client";
import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Link from "next/link";
import Navbar from "@/components/landing/Navbar";
import { Calendar, MapPin, Clock, Trophy, Music, Cpu, Camera, ChevronRight, Ticket } from "lucide-react";

type Event = {
  id: number;
  title: string;
  category: "Technical" | "Cultural" | "Sports";
  date: string;
  location: string;
  image: string;
  desc: string;
};

export default function EventsPage() {
  const [filter, setFilter] = useState<"All" | "Technical" | "Cultural" | "Sports">("All");

  const events: Event[] = [
    {
      id: 1,
      title: "Technovate 2026",
      category: "Technical",
      date: "March 15, 2026",
      location: "Main Auditorium",
      image: "/Technical/trends.jpg",
      desc: "Our annual international tech symposium featuring hackathons, AI workshops, and guest lectures from Silicon Valley leads."
    },
    {
      id: 2,
      title: "Vanguard Fiesta",
      category: "Cultural",
      date: "April 02, 2026",
      location: "Open Air Theatre",
      image: "/Cultural/CULTURAL.jpg",
      desc: "A celebration of diversity featuring musical concerts, dance competitions, and fine arts exhibitions."
    },
    {
      id: 3,
      title: "VIT Sports League",
      category: "Sports",
      date: "February 20, 2026",
      location: "Olympic Arena",
      image: "https://images.unsplash.com/photo-1504450758481-7338eba7524a?q=80&w=2069",
      desc: "The ultimate inter-departmental championship covering football, cricket, and track events."
    },
    {
      id: 4,
      title: "Cyber Security Summit",
      category: "Technical",
      date: "May 10, 2026",
      location: "Innovation Lab",
      image: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?q=80&w=2070",
      desc: "A specialized deep-dive into post-quantum cryptography and neural network defense mechanisms."
    }
  ];

  const filteredEvents = filter === "All" ? events : events.filter(e => e.category === filter);

  return (
    <main className="min-h-screen bg-white selection:bg-orange-500 selection:text-white overflow-x-hidden">
      {/* Navbar prop set to true for visibility on sub-pages */}
      <Navbar isScrolled={true} />

      {/* --- HERO SECTION: VISUAL ANCHOR --- */}
      <section className="relative pt-44 pb-32 bg-slate-950 text-white overflow-hidden">
        <div className="absolute inset-0 z-0 opacity-20">
          <div className="absolute top-0 left-0 w-[500px] h-[500px] bg-orange-600 rounded-full blur-[150px] -translate-y-1/2 -translate-x-1/2" />
          <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-blue-600 rounded-full blur-[150px] translate-y-1/2 translate-x-1/2" />
        </div>
        
        <div className="max-w-7xl mx-auto px-6 relative z-10">
          <motion.div 
            initial={{ opacity: 0, y: 20 }} 
            animate={{ opacity: 1, y: 0 }} 
            transition={{ duration: 0.8 }}
          >
            <span className="text-orange-500 font-black uppercase tracking-[0.4em] text-[10px]">Campus Pulse</span>
            <h1 className="text-6xl md:text-9xl font-black uppercase italic tracking-tighter mt-4 leading-none">
              Life at <br /> <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-500 to-yellow-400">Vanguard.</span>
            </h1>
            <p className="mt-8 text-slate-400 font-light text-lg max-w-2xl leading-relaxed">
              Experience a vibrant community where innovation, creativity, and athleticism converge. From global tech summits to cultural extravaganzas, there is always a breakthrough happening here.
            </p>
          </motion.div>
        </div>
      </section>

      {/* --- CATEGORY FILTER NAVIGATION --- */}
      <section className="sticky top-20 z-40 bg-white border-b border-slate-100 backdrop-blur-md bg-white/90">
        <div className="max-w-7xl mx-auto px-6 flex flex-wrap gap-8 md:gap-16">
          {(["All", "Technical", "Cultural", "Sports"] as const).map((cat) => (
            <button 
              key={cat}
              onClick={() => setFilter(cat)}
              className={`py-8 text-[10px] font-black uppercase tracking-[0.3em] transition-all relative ${
                filter === cat ? 'text-orange-600' : 'text-slate-400 hover:text-slate-900'
              }`}
            >
              {cat}
              {filter === cat && (
                <motion.div 
                  layoutId="eventUnderline" 
                  className="absolute bottom-0 left-0 w-full h-1 bg-orange-600" 
                />
              )}
            </button>
          ))}
        </div>
      </section>

      {/* --- EVENT LISTING GRID --- */}
      <section className="py-24 max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-2 gap-16">
          <AnimatePresence mode="popLayout">
            {filteredEvents.map((event) => (
              <motion.div
                key={event.id}
                layout
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="group"
              >
                <div className="relative aspect-[16/9] overflow-hidden rounded-sm mb-8 bg-slate-100 shadow-xl group-hover:shadow-2xl transition-all duration-500">
                  <img 
                    src={event.image} 
                    alt={event.title} 
                    className="w-full h-full object-cover grayscale group-hover:grayscale-0 group-hover:scale-105 transition-all duration-700" 
                  />
                  <div className="absolute top-6 right-6">
                    <span className="px-5 py-2 bg-white/95 backdrop-blur-sm text-[9px] font-black uppercase tracking-widest text-slate-900 border border-slate-100">
                      {event.category}
                    </span>
                  </div>
                </div>

                <div className="space-y-5">
                  <div className="flex items-center gap-8 text-[10px] font-bold text-orange-600 uppercase tracking-widest">
                    <span className="flex items-center gap-2.5"><Calendar className="w-4 h-4" /> {event.date}</span>
                    <span className="flex items-center gap-2.5"><MapPin className="w-4 h-4" /> {event.location}</span>
                  </div>
                  <h3 className="text-4xl font-black text-slate-900 uppercase tracking-tighter group-hover:text-orange-600 transition-colors">
                    {event.title}
                  </h3>
                  <p className="text-slate-500 text-sm leading-relaxed italic border-l-4 border-orange-500 pl-6 py-1">
                    "{event.desc}"
                  </p>
                  <div className="pt-4 flex items-center gap-10">
                    <button className="flex items-center gap-3 text-[10px] font-black uppercase tracking-widest text-slate-900 group-hover:gap-5 transition-all">
                      Event Details <ChevronRight className="w-4 h-4 text-orange-600" />
                    </button>
                    <button className="flex items-center gap-3 text-[10px] font-black uppercase tracking-widest text-orange-600 hover:text-slate-900 transition-colors">
                      <Ticket className="w-4 h-4" /> Register Now
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </section>

      {/* --- STUDENT ENGAGEMENT CTA --- */}
      <section className="py-32 bg-slate-950 text-center relative overflow-hidden">
         <div className="absolute inset-0 opacity-10 pointer-events-none">
            <Camera className="w-[500px] h-[500px] absolute -bottom-20 -left-20 text-white rotate-12" />
            <Music className="w-[400px] h-[400px] absolute -top-20 -right-20 text-white -rotate-12" />
         </div>
         <div className="relative z-10 px-6">
            <h2 className="text-4xl md:text-5xl font-black text-white uppercase tracking-tighter mb-8 italic">
              Lead an <span className="text-orange-500">Innovation.</span>
            </h2>
            <p className="text-slate-400 mb-12 text-sm max-w-sm mx-auto uppercase tracking-widest font-bold leading-relaxed">
              Collaborate with the Student Activity Council (SAC) to bring your vision to life.
            </p>
            <Link 
              href="/contact" 
              className="inline-block px-14 py-6 bg-orange-600 text-white font-black uppercase tracking-[0.2em] text-xs hover:bg-white hover:text-orange-600 transition-all shadow-2xl shadow-orange-600/20"
            >
              Propose an Event
            </Link>
         </div>
      </section>

      {/* --- FOOTER --- */}
      <footer className="py-16 bg-white border-t border-slate-100 text-center">
        <p className="text-[10px] font-black text-slate-300 uppercase tracking-[1em]">Vanguard Student Activity Council • Est 1998</p>
      </footer>
    </main>
  );
}