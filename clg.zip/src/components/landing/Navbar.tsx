"use client";
import Link from "next/link";

export default function Navbar({ isScrolled }: { isScrolled: boolean }) {
  return (
    <nav className={`fixed top-0 w-full z-[100] transition-all duration-500 px-6 md:px-12 h-20 flex items-center justify-between ${
      isScrolled ? "bg-white/90 backdrop-blur-md shadow-lg text-slate-900" : "bg-transparent text-white"
    }`}>
      <Link href="/" className="text-2xl font-black tracking-tighter cursor-pointer">
        VIT<span className="text-orange-600">.</span>
      </Link>
      
      <div className="flex gap-8 text-[10px] font-bold uppercase tracking-[0.2em] items-center">
        <Link href="/" className="hover:text-orange-500 transition-colors">Home</Link>
        <Link href="/about" className="hover:text-orange-500 transition-colors">About</Link>
        <Link href="/campus" className="hover:text-orange-500">Campus</Link>
        <Link href="/#programs" className="hover:text-orange-500 transition-colors hidden md:block">Programs</Link>
        <Link href="/admission-procedure" className="hover:text-orange-500 transition-colors">Procedure</Link>
        <Link href="/placements" className="hover:text-orange-500 transition-colors">Placements</Link>
        <Link href="/staff" className="hover:text-orange-500 transition-colors">Our People</Link>
        <Link href="/achievements" className="hover:text-orange-500 transition-colors">Achievements</Link>
         <Link href="/events" className="hover:text-orange-500 transition-colors">Events</Link>
         <Link href="/contact" className="hover:text-orange-500 transition-colors">Contact</Link>

        <Link 
  href="/students-corner" 
  className="bg-orange-600 text-white px-6 py-2.5 rounded-sm hover:bg-slate-900 transition-all font-black uppercase tracking-widest text-[10px]"
>
  Student's Corner
</Link>
        
      </div>
    </nav>
  );
}